package com.qa.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBase;

public class CheckoutPage extends TestBase{
	
	@FindBy(xpath="//input[@id='first-name']")
	WebElement customerFname;
	
	@FindBy(xpath="//input[@id='last-name']")
	WebElement customerLname;
	
	@FindBy(xpath="//input[@id='postal-code']")
	WebElement customerPcode;
	
	@FindBy(xpath="//input[@id='continue']")
	WebElement completeCheckoutBtn;
	
	@FindBy(xpath="//button[@id='finish']")
	WebElement finishPaymentBtn;
	
	@FindBy(xpath="//h2[contains(text(),'THANK YOU FOR YOUR ORDER')]")
	WebElement orderPlacedBanner;
	
	public CheckoutPage() {
		PageFactory.initElements(driver, this);
	}
	
	public String validatePlaceOrderSuccess(String fname, String lname, String pcode) {
		customerFname.sendKeys(fname);
		customerLname.sendKeys(lname);
		customerPcode.sendKeys(pcode);
		completeCheckoutBtn.click();
		finishPaymentBtn.click();
		return orderPlacedBanner.getText();
	}
	
}
