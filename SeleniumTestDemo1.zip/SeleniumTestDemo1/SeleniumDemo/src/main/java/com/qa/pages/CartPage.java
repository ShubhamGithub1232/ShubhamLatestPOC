package com.qa.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.qa.base.TestBase;

public class CartPage extends TestBase{

	@FindBy(xpath="//button[@class='btn btn_action btn_medium checkout_button']")
	WebElement checkoutBtn;
	
	public CartPage() {
		PageFactory.initElements(driver, this);
	}
	
	public String validateShoppingCartProduct(String prodName) {
		String cartProduct = driver.findElement(By.xpath("//div[@class='inventory_item_name' and"
				+ " contains(text(),'"+prodName+"')]")).getText();
		return cartProduct;
	}
	
	public void removeProductFromCart(String prodName) {
		driver.findElement(By.xpath("//div[contains(text(),'"+prodName+"')]//parent::a//parent::div[@class='cart_item_label']"
				+ "//following-sibling::div[@class='item_pricebar']//child::button")).click();
	}
	
	public CheckoutPage proceedToCheckout() {
		checkoutBtn.click();
		return new CheckoutPage();
	}
}
