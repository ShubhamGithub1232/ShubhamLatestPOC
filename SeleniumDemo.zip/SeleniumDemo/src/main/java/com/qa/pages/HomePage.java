package com.qa.pages;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.xml.Parser;

import com.qa.base.TestBase;

public class HomePage extends TestBase{

	@FindBy(xpath="//span[@class='title']")
	WebElement productTitle;
	
	@FindBy(xpath="//span[@class='shopping_cart_badge']")
	WebElement shoppingCartBadge;
	
	@FindBy(xpath="//a[@class='shopping_cart_link']")
	WebElement shoppingCartLink;
	
	@FindBy(xpath="//button[@id='react-burger-menu-btn']")
	WebElement addtnlMenu;
	
	@FindBy(xpath = "//a[@class='bm-item menu-item' and contains(text(),'Logout')]")
	WebElement logoutLink;
	
	@FindBy(xpath="//select[@class='product_sort_container']")
	WebElement filterDropdown;

	public HomePage() {
		PageFactory.initElements(driver, this);
	}
	
	public Boolean validateProductBanner() {
		return productTitle.isDisplayed();
	}
	
	public void addProductToCart(String prodName) {
		driver.findElement(By.xpath("//div[contains(text(),'"+prodName+"')]//"
				+ "parent::a//parent::div[@class='inventory_item_label']//following-sibling::div[@class='pricebar']//child::button")).click();
	}
	
	public String validateShoppingCartCount() {
		return shoppingCartBadge.getText();
	}
	
	public CartPage openShoppingCart() {
		shoppingCartLink.click();
		return new CartPage();
	}
	
	public LoginPage logOut() throws InterruptedException {
		addtnlMenu.click();
		Thread.sleep(1000);
		logoutLink.click();	
		return new LoginPage();
	}
	
	public void validateSortingOfItemsByName(String sortOrder){
		List<WebElement> unsorteditems = driver.findElements(By.xpath("//div[@class='inventory_item_name']"));
		 List<String> unsortedItems = new ArrayList<String>();
		 for (WebElement listItem : unsorteditems) {
			 unsortedItems.add(listItem.getText());
		    }
		
		Select sortItems = new Select(filterDropdown);
		if(sortOrder.equalsIgnoreCase("ZtoA")) {
			Collections.reverse(unsortedItems);
			sortItems.selectByVisibleText("Name (Z to A)");
		}else if(sortOrder.equalsIgnoreCase("AtoZ")) {
			sortItems.selectByVisibleText("Name (A to Z)");
		}
				
		List<WebElement> uiItems = driver.findElements(By.xpath("//div[@class='inventory_item_name']"));
		List<String> actualItems = new ArrayList<String>();
		 for (WebElement temp : uiItems) {
		        actualItems.add(temp.getText());
		    }
		 Assert.assertEquals(unsortedItems, actualItems,"The lists do not match !!");
	}
	
	public void validateSortingOfItemsByPrice(String priceOrder) {
		List<WebElement> unsorteditems = driver.findElements(By.xpath("//div[@class='inventory_item_price']"));
		 List<Double> unsortedItems = new ArrayList<Double>();
		 for (WebElement listItem : unsorteditems) {
			 unsortedItems.add(Double.parseDouble(listItem.getText().replaceAll("\\$+", "")));
		    }

		 Select sortItems = new Select(filterDropdown);
		 if(priceOrder.equalsIgnoreCase("lowtohigh")) {
				 Collections.sort(unsortedItems);
				 sortItems.selectByVisibleText("Price (low to high)");
			}else if(priceOrder.equalsIgnoreCase("hightolow")) {
				Collections.sort(unsortedItems);
				Collections.reverse(unsortedItems);
				 sortItems.selectByVisibleText("Price (high to low)");
			}
		 	 
		 List<WebElement> uiItems = driver.findElements(By.xpath("//div[@class='inventory_item_price']"));
			List<Double> actualItems = new ArrayList<Double>();
			 for (WebElement temp : uiItems) {
			        actualItems.add(Double.parseDouble(temp.getText().replaceAll("\\$+", "")));
			    }
			 Assert.assertEquals(unsortedItems , actualItems,"The lists do not match !!");
	}
	
	public void getPriceDescriptionForProduct(String product) {
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		List<WebElement> itemName= driver.findElements(By.xpath("//div[@class='inventory_item_name']"));
		for(int i=1;i<=itemName.size();i++) {
			List<String> itemsList= new ArrayList<String>();
			itemsList.add(driver.findElement(By.xpath("(//div[@class='inventory_item_price'])["+i+"]")).getText());
			itemsList.add(driver.findElement(By.xpath("(//div[@class='inventory_item_desc'])["+i+"]")).getText());
			map.put(driver.findElement(By.xpath("(//div[@class='inventory_item_name'])["+i+"]")).getText(), itemsList);
		}
		System.out.println("The price for product: "+product+" is = "+map.get(product).get(0));	
		System.out.println("The description for product: "+product+" is = "+map.get(product).get(1));	
	}
	
}
