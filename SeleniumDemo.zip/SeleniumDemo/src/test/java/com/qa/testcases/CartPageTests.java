package com.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.pages.CartPage;
import com.qa.pages.HomePage;
import com.qa.pages.LoginPage;

public class CartPageTests extends TestBase{
	
	LoginPage loginPage;
	HomePage homePage;
	CartPage cartPage;
	
	public String productName="Sauce Labs Bike Light";

	public CartPageTests() {
		super();
	}
	
	@BeforeMethod
	public void setup() {
		initialize();
		loginPage = new LoginPage();
		homePage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));
		homePage.addProductToCart(productName);
		cartPage =homePage.openShoppingCart();
	}
	
	@Test(priority=1)
	public void validateCartProductTest(){
		String prod = cartPage.validateShoppingCartProduct(productName);
		Assert.assertEquals(prod,productName,"Incorrect Product added to the cart !!");	
	}
	
	@Test(priority=2)
	public void removeCartProductTest(){
		cartPage.removeProductFromCart(productName);
	}

	
	@AfterMethod
	public void teardown() {
		driver.quit();
	}
}
