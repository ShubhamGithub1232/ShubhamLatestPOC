package com.qa.base;

import java.io.FileInputStream;
import java.util.Properties;

public class BaseClassTest {
	public Properties prop;
	
	public int RESPONSE_STATUS_CODE_200=200;
	
	public BaseClassTest() {
		try {
			prop = new Properties();
			FileInputStream ip = new FileInputStream(System.getProperty("user.dir")+"\\src\\main\\java\\com\\qa\\config\\config.properties");
			prop.load(ip);
		}catch(Exception e) {
			e.printStackTrace();
		}
	}

}
