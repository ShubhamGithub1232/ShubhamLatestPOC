package com.qa.tests;

import java.io.IOException;
import java.util.HashMap;

import org.apache.http.Header;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.BaseClassTest;
import com.qa.client.RestClient;

public class GetAPITest extends BaseClassTest{

	BaseClassTest baseClass;
	String url;
	String serviceUrl;
	String finalURL;
	RestClient restClient;
	CloseableHttpResponse closeableHttpResponse;
	
	@BeforeMethod
	public void setUp(){
		baseClass = new BaseClassTest();
		url = prop.getProperty("URL");
		serviceUrl = prop.getProperty("serviceURL");
		
		finalURL = url+serviceUrl;
	}
	
	@Test
	public void getData() throws ClientProtocolException, IOException {
		restClient = new RestClient();
		closeableHttpResponse= restClient.get(finalURL);
		
		int statusCode = closeableHttpResponse.getStatusLine().getStatusCode();
		System.out.println("Status Code: "+statusCode);
		
		Assert.assertEquals(statusCode,RESPONSE_STATUS_CODE_200," Status Code is not correct !!");
		
		String responseString = EntityUtils.toString(closeableHttpResponse.getEntity(),"UTF-8");
		
		JSONObject responseJson = new JSONObject(responseString);
		System.out.println("Response JSON from API: "+responseJson);
		
		Header[] headersArray = closeableHttpResponse.getAllHeaders();
		
		HashMap<String, String> allHeaders = new HashMap<String, String>();
		for(Header headers : headersArray) {
			allHeaders.put(headers.getName(), headers.getValue());
		}
		
		System.out.println("All Headers: "+allHeaders);
	}
}
