package com.qa.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.Map;

import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

import com.qa.base.TestBase;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
 

public class TestUtil extends TestBase{

	public static long PAGE_LOAD_TIMEOUT=20;
	public static long IMPLICIT_WAIT=10;
	
	public static String TEST_DATA_EXCEL_PATH="C:\\Users\\shubham.gupta2\\eclipse-workspace"
			+ "\\SeleniumDemo\\src\\main\\java\\com\\qa\\testdata\\DemoTestData.xlsx";
	
	static Workbook book;
	static Sheet sheet;
	
	public static Object[][] getTestData(String sheetName){
		FileInputStream file = null;
		try {
			file = new FileInputStream(TEST_DATA_EXCEL_PATH);
		}catch(FileNotFoundException e) {
			e.printStackTrace();
		}
		try {
			book = WorkbookFactory.create(file);
		}catch(Exception e) {
			e.printStackTrace();
		}
		sheet = book.getSheet(sheetName);
		Object[][] data = new Object[sheet.getLastRowNum()][sheet.getRow(0).getLastCellNum()];
		for(int i=0;i<sheet.getLastRowNum();i++) {
			for(int k=0;k<sheet.getRow(0).getLastCellNum();k++) {
				data[i][k] = sheet.getRow(i+1).getCell(k).toString();
			}
		}
		return data;
		
	}
	
	public static void updateConfigFile() {
        try {
            PropertiesConfiguration properties = new PropertiesConfiguration("C:\\Users\\shubham.gupta2\\git\\SeleniumTestDemo1\\SeleniumDemo\\src\\main\\java\\com\\qa\\config\\temp.properties");
            Map<String, String> env = System.getenv();  
            for (String envName : env.keySet()) {
            	if(envName.contains("SG_")&&(System.getenv(envName)!=null)) {
            		 properties.setProperty(envName,System.getenv(envName));
            	}
            }
            properties.save();
            System.out.println("config.properties updated Successfully!!");
        } catch (ConfigurationException e) {
            System.out.println(e.getMessage());
        }
    }
}
