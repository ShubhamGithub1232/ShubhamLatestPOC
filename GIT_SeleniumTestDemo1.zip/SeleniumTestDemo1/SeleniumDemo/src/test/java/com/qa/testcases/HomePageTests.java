package com.qa.testcases;

import org.openqa.selenium.By;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.pages.HomePage;
import com.qa.pages.LoginPage;
import com.qa.util.TestUtil;

public class HomePageTests extends TestBase{
	
	HomePage homePage;
	LoginPage loginPage;
	public String MULTIPLE_PRODUCTS_SHEET="MultipleProducts";
	public String ITEMS_SHEET="ItemsList";
	
	public HomePageTests() {
		super();
	}
	
	@BeforeMethod
	public void setup() {
		initialize();
		loginPage = new LoginPage();
		homePage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));
	}
	
	
	@Test(priority=1)
	public void valdiateProductBannerTest() { 
		Assert.assertTrue(homePage.validateProductBanner());
	}
	
	@Test(priority=2)
	public void addSingleProductToCartTest(){
		homePage.addProductToCart("Sauce Labs Bike Light");
		String shoppingCartItems = homePage.validateShoppingCartCount();
		Assert.assertEquals(Integer.parseInt(shoppingCartItems),1,"Mismatch in the number of Items !!");
	}
	

	@DataProvider
	public Object[][] getDemoTestData() {
		Object [][] data =TestUtil.getTestData(MULTIPLE_PRODUCTS_SHEET);
		return data;
	}
	
	@Test(priority=3,dataProvider = "getDemoTestData")
	public void addMultipleProductsTest(String Product){
		homePage.addProductToCart(Product);
	}
	
	@Test(priority=4)
	public void logOutTest() throws InterruptedException {
		loginPage = homePage.logOut();
		Boolean logout =loginPage.validateLoginButton();
		Assert.assertTrue(logout,"Logout was unsuccessful !!");
	}
	
	@Test(priority=5)
	public void validateSortingOfItemsByNameTest(){
		homePage.validateSortingOfItemsByName("AtoZ");
	}
	
	@Test(priority=6)
	public void validateSortingOfItemsByPrice(){
		homePage.validateSortingOfItemsByPrice("lowtohigh");
	}
	
	@DataProvider
	public Object[][] getItemsTestData() {
		Object [][] data =TestUtil.getTestData(ITEMS_SHEET);
		return data;
	}
	
	@Test(priority=7,dataProvider = "getItemsTestData")
	public void getPriceDescriptionForProductTest(String Product) {
		homePage.getPriceDescriptionForProduct(Product);
	}
	
	@Test(priority=8)
	public void validatePriceDescPOJOTest() {
		homePage.validatePriceDescPOJO("Backpack");
	}
	
	@Test(priority=9)
	public void validatePOJO() {
		homePage.validatePojo();
	}
	@AfterMethod
	public void teardown() {
		driver.quit();
	}

}
