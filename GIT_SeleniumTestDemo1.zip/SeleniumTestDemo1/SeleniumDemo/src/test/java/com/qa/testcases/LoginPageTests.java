package com.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.pages.HomePage;
import com.qa.pages.LoginPage;

public class LoginPageTests extends TestBase{

	HomePage homePage;
	LoginPage loginPage;
	
	public LoginPageTests() {
		super();
	}
	
	@BeforeMethod
	public void setup() {
		initialize();
		loginPage = new LoginPage();
	}
	
	@Test(priority=1)
	public void validateTitleTest() {
		String title =	loginPage.getTitle();
		Assert.assertEquals(title, "Swag Labs");
	}
	
	@Test(priority=2)
	public void loginTest(){
		homePage = loginPage.login(prop.getProperty("username"),prop.getProperty("password"));
	}
	
	@AfterMethod
	public void teardown() {
			driver.quit();
			
	}
}
