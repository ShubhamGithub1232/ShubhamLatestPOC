package com.qa.testcases;

import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.qa.base.TestBase;
import com.qa.pages.CartPage;
import com.qa.pages.CheckoutPage;
import com.qa.pages.HomePage;
import com.qa.pages.LoginPage;

public class CheckoutPageTests extends TestBase{

	LoginPage loginPage;
	HomePage homePage;
	CartPage cartPage;
	CheckoutPage checkoutPage;
	
	public String productName="Sauce Labs Bike Light";
	public String ORDER_PLACED_BANNER="THANK YOU FOR YOUR ORDER";
	
	public CheckoutPageTests() {
		super();
	}
	
	@BeforeMethod
	public void setup() {
		initialize();
		loginPage = new LoginPage();
		homePage = loginPage.login(prop.getProperty("username"), prop.getProperty("password"));
		homePage.addProductToCart(productName);
		cartPage =homePage.openShoppingCart();
		checkoutPage = cartPage.proceedToCheckout();
	}
	
	@Test
	public void validateOrderCompletionTest() {
		String orderStaus =checkoutPage.validatePlaceOrderSuccess("temp", "temp2", "temp3");
		Assert.assertEquals(orderStaus,ORDER_PLACED_BANNER,"Order Completion Failed !!");
	}
	
	@AfterMethod
	public void teardown() {
		driver.quit();
	}
}
